Silakan tambahkan:
- logo.png (logo kecil di sebelah teks PADALAJA)
- hero-bg.jpg (gambar latar belakang hero banner)
- map_kaltim.svg
pada folder ini sesuai nama file di kode.