<?php
// navbar.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-black fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">PADALAJA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNav" aria-controls="navbarNav"
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-center">

        <?php if (isset($_SESSION['username'])): ?>
        <li class="nav-item dropdown">
          <!-- Username sebagai toggle -->
          <a class="dropdown-item"
             href="#"
             id="userDropdown"
             role="button"
             data-bs-toggle="dropdown"
             aria-expanded="false">
            Halo <?= htmlspecialchars($_SESSION['username']) ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end"
              aria-labelledby="userDropdown">
            <!-- Role-specific links -->
            <?php if ($_SESSION['role'] === 'admin'): ?>
              <li><a class="dropdown-item" href="index.php">Beranda</a></li>
              <li><a class="dropdown-item" href="admin_aduan.php">Kelola Aduan</a></li>
              <li><a class="dropdown-item" href="predict.php">Fast API</a></li>
              <li><a class="dropdown-item" href="desbord.php">Dashboard</a></li>
              <li><a class="dropdown-item" href="berita.php">Tambah Progress</a></li>
            <?php elseif ($_SESSION['role'] === 'user'): ?>
              <li><a class="dropdown-item" href="index.php">Beranda</a></li>
              <li><a class="dropdown-item" href="user_aduan.php">Aduan Saya</a></li>
            <?php endif; ?>
            <li><hr class="dropdown-divider"></li>
            <!-- Logout -->
            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
          </ul>
        </li>

        <?php else: /* belum login */ ?>
        <li class="nav-item">
          <a class="nav-link btn-pill btn-pill-dark" href="login.php">Login</a>
        </li>
        <?php endif; ?>

      </ul>
    </div>
  </div>
</nav>


