<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
  header('Location: login.php');
  exit;
}
require 'config.php';

// Pastikan ada user_id di session untuk mengidentifikasi aduan dari user yang login
if (!isset($_SESSION['user_id'])) {
  header('Location: login.php'); // Redirect jika user_id tidak ada
  exit;
}

$user_id = intval($_SESSION['user_id']);

// Hapus aduan jika diminta
if (isset($_GET['hapus'])) {
  $id = intval($_GET['hapus']);
  // Hapus file lampiran di storage
  $resLamp = $conn->query("SELECT file_path FROM lampiran_aduan WHERE aduan_id = $id");
  while ($r = $resLamp->fetch_assoc()) {
    if (file_exists($r['file_path'])) unlink($r['file_path']);
  }
  // Hapus record di database
  $conn->query("DELETE FROM lampiran_aduan WHERE aduan_id = $id");
  $conn->query("DELETE FROM aduan WHERE id = $id");
  echo "<script>
            alert('Aduan berhasil dihapus!');
            window.location='admin_aduan.php';
          </script>";
  exit;
}

// Ambil daftar aduan untuk user yang sedang login
$aduan = $conn->query("
    SELECT aduan.*, user.nama AS nama_user
    FROM aduan
    LEFT JOIN user ON aduan.user_id = user.id
    WHERE aduan.user_id = $user_id
    ORDER BY aduan.tanggal_aduan DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin – Data Aduan</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
</head>

<body class="aduan-page-bg d-flex flex-column min-vh-100">

  <?php include 'navbar.php'; ?>

  <section class="content-section py-5 bg-dark">
    <section id="tips" class="py-5">
      <div class="container">
        <h1 class="mb-4">Daftar Aduan Pengguna</h1>
        <?php if ($aduan && $aduan->num_rows > 0): ?>
          <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php while ($row = $aduan->fetch_assoc()):
              $id       = $row['id'];
              $isi      = nl2br(htmlspecialchars($row['isi_aduan']));
              $lokasi   = htmlspecialchars($row['lokasi_aduan']);
              $tgl      = date("d M Y, H:i", strtotime($row['tanggal_aduan']));
              $namaUser = htmlspecialchars($row['nama_user'] ?? 'Pengguna Tidak Dikenal');

              // Ambil lampiran file_path
              $resLamp  = $conn->query("SELECT file_path FROM lampiran_aduan WHERE aduan_id = $id");
              $files    = [];
              while ($l = $resLamp->fetch_assoc()) {
                $files[] = $l['file_path'];
              }
            ?>
              <div class="col">
                <div class="card h-100 shadow-sm">
                  <img src="<?= htmlspecialchars($files[0] ?? 'img/default-image.jpg') ?>"
                    alt="Aduan #<?= $id ?>"
                    class="card-img-top">

                  <div class="card-body d-flex flex-column position-relative">

                    <h5 class="card-title">Aduan #<?= $id ?> dari <strong><?= $namaUser ?></strong></h5>
                    <p class="card-text"><i class="far fa-clock me-1"></i><?= $tgl ?></p>
                    <p class="card-text flex-grow-1"><?= $isi ?></p>
                    <p class="card-text"><i class="fas fa-map-marker-alt me-1"></i><?= $lokasi ?></p>

                    <?php if (!empty($files)): ?>
                      <div class="lampiran-group mt-auto">
                        <small><strong>Lampiran:</strong></small><br>
                        <?php foreach ($files as $file): ?>
                          <a href="<?= htmlspecialchars($file) ?>"
                            target="_blank"
                            class="btn btn-outline-primary btn-sm me-1 mb-1">
                            <i class="fas fa-eye"></i>
                          </a>
                        <?php endforeach; ?>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        <?php else: ?>
          <div class="alert alert-info text-center">
            Belum ada aduan masuk.
          </div>
        <?php endif; ?>

      </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>