<?php
// Konfigurasi database
$host = "localhost";     // atau IP server MySQL
$user = "root";          // username database
$password = "";          // password database
$database = "padalaja";  // nama database

// Membuat koneksi
$conn = new mysqli('localhost', 'root', '', 'padalaja');


// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Jika berhasil
// echo "Koneksi berhasil ke database padalaja";
?>
