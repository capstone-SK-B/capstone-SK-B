<?php
session_start();
require 'config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek admin
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result_admin = $stmt->get_result();

    if ($result_admin->num_rows > 0) {
        $_SESSION['role'] = 'admin';
        $_SESSION['username'] = $result_admin->fetch_assoc()['username'];
        header("Location: admin_aduan.php");
        exit;
    }

    // Cek user
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result_user = $stmt->get_result();

    if ($result_user->num_rows > 0) {
        $user = $result_user->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['role'] = 'user';
            $_SESSION['username'] = $user['nama'];
            $_SESSION['user_id'] = $user['id'];
            header("Location: index.php");
            exit;
        }
    }

    $error = 'Login gagal. Cek kembali username/email dan password.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <!-- Bootstrap 5 & Custom CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">
  <?php include 'navbar.php'; ?>

  <main class="flex-fill d-flex align-items-center justify-content-center">
    <section class="hero-section login-section" style="background-image: url('images/background login.jpg')">
      <div class="card login-card shadow">
        <div class="card-body p-5">
          <h2 class="login-title mb-4 text-center">Login User</h2>
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>
          <form method="POST" class="login-form">
            <!-- Email row -->
            <div class="d-flex mb-3 align-items-center">
              <label for="username" class="me-3 mb-0" style="white-space: nowrap; width: 80px;">Email</label>
              <input id="username" name="username" type="text" class="form-control flex-grow-1" placeholder="email@example.com" required>
            </div>
            <!-- Password row -->
            <div class="d-flex mb-4 align-items-center">
              <label for="password" class="me-3 mb-0" style="white-space: nowrap; width: 80px;">Password</label>
              <input id="password" name="password" type="password" class="form-control flex-grow-1" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>
            <a href="register.php" class="btn btn-secondary w-100">Daftar Akun</a>
          </form>
        </div>
      </div>
    </section>
  </main>

  <?php include 'footer.php'; ?>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>