<?php
session_start();
require 'config.php';

// Pastikan role user
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    echo "<script>
            alert('🚫 Akses ditolak. Anda harus login sebagai user.');
            window.location.href = 'login.php';
          </script>";
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {
    $isi_aduan = trim($_POST['isi_aduan'] ?? '');
    $lokasi    = trim($_POST['lokasi_aduan'] ?? '');

    // Validasi
    if (strlen($isi_aduan) < 50 || strlen($isi_aduan) > 500 || empty($lokasi)) {
        echo "<script>
                alert('⚠️ Data tidak valid. Pastikan semua field terisi dengan benar.');
                window.history.back();
              </script>";
        exit;
    }

    // Simpan aduan
    $stmt = $conn->prepare("INSERT INTO aduan (user_id, isi_aduan, lokasi_aduan) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $isi_aduan, $lokasi);

    if ($stmt->execute()) {
        $aduan_id = $stmt->insert_id;
        $stmt->close();

        // Tangani file upload
        if (isset($_FILES['lampiran']) && is_array($_FILES['lampiran']['tmp_name'])) {
            $upload_base = __DIR__ . '/uploads/';
            if (!is_dir($upload_base)) {
                mkdir($upload_base, 0755, true);
            }

            foreach ($_FILES['lampiran']['tmp_name'] as $i => $tmp_name) {
                if ($_FILES['lampiran']['error'][$i] !== UPLOAD_ERR_OK) continue;
                $size = $_FILES['lampiran']['size'][$i];
                $type = $_FILES['lampiran']['type'][$i];

                // validasi tipe & ukuran
                if ($size > 0 && $size <= 5*1024*1024 && preg_match('/^image\\//', $type)) {
                    $origName = basename($_FILES['lampiran']['name'][$i]);
                    $ext      = pathinfo($origName, PATHINFO_EXTENSION);
                    $newName  = uniqid('img_') . ".{$ext}";
                    $destPath = $upload_base . $newName;

                    if (move_uploaded_file($tmp_name, $destPath)) {
                        $relative = 'uploads/' . $newName;
                        $stmt2 = $conn->prepare(
                            "INSERT INTO lampiran_aduan (aduan_id, file_path, file_type) VALUES (?, ?, ?)"
                        );
                        $stmt2->bind_param("iss", $aduan_id, $relative, $type);
                        $stmt2->execute();
                        $stmt2->close();
                    }
                }
            }
        }

        // Redirect sukses
        echo "<script>
                alert('✅ Aduan berhasil dikirim!');
                window.location.href = 'index.php';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('❌ Gagal menyimpan aduan. Silakan coba lagi.');
                window.history.back();
              </script>";
        exit;
    }
} else {
    echo "<script>
            alert('⚠️ Metode tidak valid.');
            window.history.back();
          </script>";
    exit;
}
?>
