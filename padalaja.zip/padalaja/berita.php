<?php
session_start();
require 'config.php';

// Cek admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Akses ditolak. Anda bukan admin.";
    exit;
}

// Proses tambah progress
if (isset($_POST['submit'])) {
    $judul = $conn->real_escape_string($_POST['judul']);
    $jalan = $conn->real_escape_string($_POST['jalan']);

    $targetDir = "uploads/";
    $fileName = basename($_FILES["foto"]["name"]);
    $targetFilePath = $targetDir . time() . "_" . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $allowTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileType, $allowTypes)) {
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $targetFilePath)) {
            $sql = "INSERT INTO progress_jalan (judul, jalan, foto) VALUES ('$judul', '$jalan', '$targetFilePath')";
            if (!$conn->query($sql)) {
                echo "Gagal simpan ke database: " . $conn->error;
            }
        } else {
            echo "Upload gambar gagal.";
        }
    } else {
        echo "Format gambar tidak valid. Harus jpg, jpeg, png, atau gif.";
    }
}

// Proses hapus progress
if (isset($_POST['hapus_id'])) {
    $hapus_id = intval($_POST['hapus_id']);

    $sql_foto = "SELECT foto FROM progress_jalan WHERE id = $hapus_id";
    $result_foto = $conn->query($sql_foto);
    if ($result_foto && $result_foto->num_rows > 0) {
        $row = $result_foto->fetch_assoc();
        if (file_exists($row['foto'])) unlink($row['foto']);
    }

    $sql_delete = "DELETE FROM progress_jalan WHERE id = $hapus_id";
    if (!$conn->query($sql_delete)) {
        echo "Gagal menghapus data: " . $conn->error;
    }
}

// Ambil data progress jalan
$sql = "SELECT * FROM progress_jalan ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <title>Kelola Progress Jalan - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="container py-5">
    <?php include 'navbar.php'; ?>
    <section id="tips" class="py-5">
      <div class="container">
        <h1 class="mb-4">Tambah Progress Jalan</h1>
    <form method="POST" enctype="multipart/form-data" class="mb-5">
        <div class="mb-3">
            <label class="form-label">Judul Progress</label>
            <input type="text" name="judul" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nama Jalan</label>
            <input type="text" name="jalan" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Upload Gambar Jalan</label>
            <input type="file" name="foto" class="form-control" accept="image/*" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
    </form>

    <h2>Daftar Progress Jalan</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Judul</th>
                <th>Nama Jalan</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0) : ?>
                <?php while ($row = $result->fetch_assoc()) : ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['judul']); ?></td>
                        <td><?= htmlspecialchars($row['jalan']); ?></td>
                        <td>
                            <?php if ($row['foto'] && file_exists($row['foto'])) : ?>
                                <img src="<?= htmlspecialchars($row['foto']); ?>" alt="Foto Jalan" style="width: 120px; height: auto;">
                            <?php else : ?>
                                Tidak ada foto
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" onsubmit="return confirm('Yakin ingin menghapus progress ini?');" style="display:inline;">
                                <input type="hidden" name="hapus_id" value="<?= $row['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada progress jalan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>

</html>
