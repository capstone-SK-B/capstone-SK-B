<?php
session_start();
require 'config.php';

// Jika belum login sebagai user, redirect
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
  header('Location: login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Form Lapor Jalan</title>
  <!-- Bootstrap & Choices & FontAwesome & CSS Anda -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="css/style.css">
</head>

<body class="d-flex flex-column min-vh-100 pt-5">

  <?php include 'navbar.php'; ?>

  <main
    class="content-section py-5"
    style="
      background-image: url('images/background fitur.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    ">
    <div class="container">
      <div class="card mx-auto shadow" style="max-width: 600px;">
        <div class="card-body">

          <h2 class="about-title text-center mb-4">Form Pengaduan Kerusakan Jalan</h2>

          <!-- Single Form -->
          <form
            id="aduanForm"
            action="submit_aduan.php"
            method="POST"
            enctype="multipart/form-data">

            <!-- Lampiran -->
            <div class="mb-3">
              <label class="form-label">Lampiran Aduan *</label>
              <div class="upload-area rounded p-4 text-center" onclick="lampiran.click()">
                <i class="fas fa-image fa-2x mb-2"></i>
                <p class="mb-0">
                  Klik untuk pilih atau drag & drop<br>
                  <small>JPEG, PNG (max 5 MB, hingga 3 file)</small>
                </p>
              </div>
              <input
                type="file"
                id="lampiran"
                name="lampiran[]"
                accept="image/jpeg,image/png"
                multiple
                style="display:none;">
              <div id="file-error" class="form-text text-danger" style="display:none;">
                Harus ada minimal 1 lampiran!
              </div>
              <div id="upload-preview" class="d-flex flex-wrap gap-2 mt-2"></div>
            </div>

            <!-- Isi Aduan -->
            <div class="mb-3">
              <label for="isi_aduan" class="form-label">
                Isi Aduan * (50–500 karakter)
              </label>
              <textarea
                id="isi_aduan"
                name="isi_aduan"
                class="form-control bg-transparent text-white"
                minlength="50"
                maxlength="500"
                placeholder="Masukkan isi aduan..."
                required></textarea>
              <div class="form-text text-white">
                <span id="current-count">0</span>/500
              </div>
              <div id="min-error" class="form-text text-danger" style="display:none;">
                Minimal 50 karakter!
              </div>
            </div>

            <!-- Lokasi -->
            <div class="mb-3">
              <label for="lokasi_aduan" class="form-label">
                Lokasi Aduan *
              </label>
              <select
                id="lokasi_aduan"
                name="lokasi_aduan"
                class="form-select bg-white text-dark"
                required>
                <option value="">Pilih lokasi</option>
                <option value="Kota Balikpapan">Kota Balikpapan</option>
                <option value="Kota Samarinda">Kota Samarinda</option>
                <option value="Kota Bontang">Kota Bontang</option>
                <option value="Kabupaten Berau">Kabupaten Berau</option>
                <option value="Kabupaten Kutai Barat">Kabupaten Kutai Barat</option>
                <option value="Kabupaten Kutai Kartanegara">Kabupaten Kutai Kartanegara</option>
                <option value="Kabupaten Kutai Timur">Kabupaten Kutai Timur</option>
                <option value="Kabupaten Mahakam Ulu">Kabupaten Mahakam Ulu</option>
                <option value="Kabupaten Paser">Kabupaten Paser</option>
                <option value="Kabupaten Penajam Paser Utara">Kabupaten Penajam Paser Utara</option>
              </select>
            </div>

            <!-- Hidden confirm -->
            <input type="hidden" name="confirm" value="1">

            <!-- Buttons -->
            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary btn-back" style="display:none;">
                &larr; Kembali
              </button>
              <button type="button" class="btn btn-primary btn-next">
                Selanjutnya &gt;
              </button>
              <button type="submit" class="btn btn-success" style="display:none;">
                Kirim Aduan
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <?php include 'footer.php'; ?>

  <!-- JS dependencies -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // ————— JS STEP Wizard & Preview —————
    document.addEventListener('DOMContentLoaded', () => {
      // Init select2
      new Choices(document.getElementById('lokasi_aduan'), {
        searchEnabled: true,
        itemSelectText: '',
        shouldSort: false,
        placeholderValue: 'Cari lokasi…',
        searchPlaceholderValue: 'Ketik untuk mencari…'
      });

      const lampiran = document.getElementById('lampiran');
      const uploadArea = document.querySelector('.upload-area');
      const previewContainer = document.getElementById('upload-preview');
      const ta = document.getElementById('isi_aduan');
      const counter = document.getElementById('current-count');
      const minError = document.getElementById('min-error');
      const fileError = document.getElementById('file-error');
      const btnNext = document.querySelector('.btn-next');
      const btnBack = document.querySelector('.btn-back');
      const btnSubmit = document.querySelector('button[type="submit"]');
      const form = document.getElementById('aduanForm');
      let dt = new DataTransfer();

      function renderPreview() {
        previewContainer.innerHTML = '';
        Array.from(dt.files).forEach((file, idx) => {
          if (!file.type.startsWith('image/')) return;
          const reader = new FileReader();
          reader.onload = e => {
            const thumb = document.createElement('div');
            thumb.className = 'thumb position-relative';
            thumb.innerHTML = `
            <img src="${e.target.result}" class="img-thumbnail" style="max-width:120px;">
            <button type="button" class="btn-close position-absolute top-0 end-0"></button>
          `;
            thumb.querySelector('.btn-close').addEventListener('click', () => {
              dt.items.remove(idx);
              lampiran.files = dt.files;
              renderPreview();
            });
            previewContainer.appendChild(thumb);
          };
          reader.readAsDataURL(file);
        });
        lampiran.files = dt.files;
      }

      lampiran.addEventListener('change', e => {
        Array.from(e.target.files).forEach(file => {
          if (dt.items.length < 3 && file.type.startsWith('image/')) {
            dt.items.add(file);
          }
        });
        renderPreview();
      });

      ta.addEventListener('input', () => {
        counter.textContent = ta.value.length;
        minError.style.display = ta.value.length < 50 ? 'block' : 'none';
      });

      btnNext.addEventListener('click', () => {
        // Validasi
        if (dt.files.length === 0) {
          fileError.style.display = 'block';
          return;
        } else fileError.style.display = 'none';
        if (ta.value.length < 50) {
          ta.focus();
          return;
        }
        if (!document.getElementById('lokasi_aduan').value) {
          alert('Pilih lokasi aduan!');
          return;
        }
        // Sembunyikan next, tampil submit/back
        btnNext.style.display = 'none';
        btnBack.style.display = 'inline-block';
        btnSubmit.style.display = 'inline-block';
      });

      btnBack.addEventListener('click', () => {
        btnNext.style.display = 'inline-block';
        btnBack.style.display = 'none';
        btnSubmit.style.display = 'none';
      });
    });
  </script>
  
</body>

</html>