<footer class="footer-section">
  <div class="container footer-top d-flex flex-wrap justify-content-between py-5">
    <div class="footer-col mb-4">
      <h4 class="footer-title">DPUPR-PERA<br/>PROV. KALTIM</h4>
      <p class="footer-text">
        Jalan Tepian Pandan No.1<br/>
        Samarinda, Kalimantan Timur 75243
      </p>
      <p class="footer-text">
        Telp. (0541)-276236<br/>
        Email: info@dpupr.kaltimprov.go.id
      </p>
    </div>

    <div class="footer-col mb-4">
      <h5 class="footer-subtitle">Link Terkait</h5>
      <ul class="footer-list">
        <li><a href="#">PU Kota Samarinda</a></li>
        <li><a href="#">PU Kota Balikpapan</a></li>
      </ul>
    </div>

    <div class="footer-col mb-4">
      <h5 class="footer-subtitle">Layanan</h5>
      <ul class="footer-list">
        <li><a href="#">Pertimbangan Teknis Tata Ruang</a></li>
        <li><a href="#">Ijin Sumber Daya Air</a></li>
      </ul>
    </div>
  </div>

  <div class="footer-bottom text-center py-3">
    <small>© Dinas Pekerjaan Umum …</small>
  </div>
</footer>
