<?php
session_start();
require 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek email terdaftar
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check = $stmt->get_result();

    if ($check->num_rows > 0) {
        $error = "Email sudah terdaftar.";
    } else {
        $stmt = $conn->prepare("INSERT INTO user (nama, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nama, $email, $password);
        if ($stmt->execute()) {
            $success = "Registrasi berhasil. Silakan login.";
        } else {
            $error = "Gagal mendaftar.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Daftar Akun</title>
  <!-- Bootstrap & Custom CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <style>
    /* Prevent label wrapping */
    .form-label-inline {
      white-space: nowrap;
    }
  </style>
</head>
<body class="d-flex flex-column min-vh-100">

  <?php include 'navbar.php'; ?>

  <section class="hero-section login-background" style="background-image: url('images/background login.jpg')">
    <div class="card login-card shadow">
      <div class="card-body p-5">
        <h2 class="login-title mb-4 text-center">Daftar Pengguna Baru</h2>
        <?php if ($error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
          <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <form method="POST" class="login-form">
          <div class="row mb-3 align-items-center">
            <label for="nama" class="col-sm-3 col-form-label text-sm-end form-label-inline">Nama</label>
            <div class="col-sm-9">
              <input id="nama" name="nama" type="text" class="form-control" placeholder="Nama lengkap" required>
            </div>
          </div>
          <div class="row mb-3 align-items-center">
            <label for="email" class="col-sm-3 col-form-label text-sm-end form-label-inline">Email</label>
            <div class="col-sm-9">
              <input id="email" name="email" type="email" class="form-control" placeholder="email@example.com" required>
            </div>
          </div>
          <div class="row mb-4 align-items-center">
            <label for="password" class="col-sm-3 col-form-label text-sm-end form-label-inline">Password</label>
            <div class="col-sm-9">
              <input id="password" name="password" type="password" class="form-control" placeholder="••••••••" required>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-sm-3"></div>
            <div class="col-sm-9">
              <button type="submit" class="btn btn-primary w-100">Daftar</button>
            </div>
          </div>
        </form>
        <div class="row">
          <div class="col-sm-3"></div>
          <div class="col-sm-9">
            <a href="login.php" class="btn btn-secondary w-100">Login di sini</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php include 'footer.php'; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>