<?php
// dashboard.php  (atau nama file .php kamu)
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard Jalan - Streamlit</title>

  <!-- Bootstrap (jika perlu) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <section class="content-section py-5 bg-dark">
    <section id="tips" class="py-5">
      <div class="container">
        <h2 class="mb-4">Dashboard Jalan</h2>
    <div class="ratio ratio-16x9">
      <iframe
        src="https://dashboardskb.streamlit.app/?embed=true&embed_options=show_toolbar&embed_options=dark_theme"
        title="Dashboard Jalan"
        allowfullscreen
        loading="lazy"
      ></iframe>
    </div>
  </main>

  <!-- Footer (jika ada) -->


  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
