<?php
require 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prediksi Kondisi Jalan</title>
    <!-- Bootstrap & Custom CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<main class="d-flex align-items-center justify-content-center" style="min-height: calc(150vh - 100px);">
    <div class="container">

        <!-- Form Prediksi -->
        <div class="card mx-auto" style="max-width: 500px;">
            <div class="card-body">
                <h5 class="card-title text-center mb-4">Form Prediksi Kondisi Jalan</h5>
                <form id="predictForm" class="row g-3">
                    <div class="col-12">
                        <label for="Panjang_Ruas_Km" class="form-label">Panjang Ruas (Km)</label>
                        <input type="number" step="any" class="form-control" id="Panjang_Ruas_Km" name="Panjang_Ruas_Km" required>
                    </div>
                    <div class="col-12">
                        <label for="Aspal" class="form-label">Aspal</label>
                        <input type="number" step="any" class="form-control" id="Aspal" name="Aspal" required>
                    </div>
                    <div class="col-12">
                        <label for="Beton" class="form-label">Beton</label>
                        <input type="number" step="any" class="form-control" id="Beton" name="Beton" required>
                    </div>
                    <div class="col-12">
                        <label for="Kerikil" class="form-label">Kerikil</label>
                        <input type="number" step="any" class="form-control" id="Kerikil" name="Kerikil" required>
                    </div>
                    <div class="col-12">
                        <label for="Tanah" class="form-label">Tanah</label>
                        <input type="number" step="any" class="form-control" id="Tanah" name="Tanah" required>
                    </div>
                    <div class="col-12">
                        <label for="Rasio_Baik" class="form-label">Rasio Baik</label>
                        <input type="number" step="any" class="form-control" id="Rasio_Baik" name="Rasio_Baik" required>
                    </div>
                    <div class="col-12">
                        <label for="Rasio_Rusak" class="form-label">Rasio Rusak</label>
                        <input type="number" step="any" class="form-control" id="Rasio_Rusak" name="Rasio_Rusak" required>
                    </div>
                    <div class="col-12 d-grid mt-3">
                        <button type="submit" class="btn btn-primary">Prediksi</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Hasil Prediksi -->
        <div id="predictionResult" class="card mx-auto mt-4" style="max-width: 500px; display: none;">
            <div class="card-body">
                <h5 class="card-title">Hasil Prediksi</h5>
                <pre id="hasilPrediksi" class="mb-0" style="white-space: pre-wrap; word-break: break-word;">Belum ada hasil.</pre>
            </div>
        </div>

    </div>
</main>

<script>
    document.getElementById('predictForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const data = {};
        new FormData(this).forEach((v, k) => data[k] = parseFloat(v));

        fetch('https://fastapicapstoneskb-production.up.railway.app/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(r => r.ok ? r.json() : Promise.reject('Gagal ambil data'))
            .then(json => {
                document.getElementById('hasilPrediksi').textContent = JSON.stringify(json, null, 2);
                document.getElementById('predictionResult').style.display = 'block';
            })
            .catch(err => {
                document.getElementById('hasilPrediksi').textContent = 'Error: ' + err;
                document.getElementById('predictionResult').style.display = 'block';
            });
    });
</script>


</html>