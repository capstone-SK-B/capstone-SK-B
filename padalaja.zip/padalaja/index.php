<?php
session_start();
require 'config.php';

// Batasi akses fungsi penghapusan hanya untuk admin
if (isset($_GET['hapus'])) {
    if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
        echo "<script>alert('Anda tidak memiliki akses untuk menghapus data.'); window.location.href='index.php';</script>";
        exit;
    }
    $idHapus = intval($_GET['hapus']);
    $conn->query("DELETE FROM progress_jalan WHERE id = $idHapus");
    header('Location: index.php');
    exit;
}

// Ambil data progress_jalan terbaru
$progress = $conn->query("SELECT * FROM progress_jalan ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Portal Lapor Jalan</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <?php include 'navbar.php'; ?>

  <!-- Hero Section -->
  <section class="hero-section" style="background-image: url('images/tol.jpeg');">
    <div class="overlay"></div>
    <div class="hero-text">
      <h1>Suara Jalanmu<br />Tindak Nyata Kami!</h1>
      <a href="lapor.php" class="btn btn-primary btn-lg mt-3">Lapor Jalan Mu!</a>
    </div>
  </section>

  <!-- Progress Jalan -->
  <section id="progress_jalan" class="content-section py-5">
    <div class="container">
      <div class="d-flex align-items-center mb-4">
        <h2>Dokumentasi Progress Jalan</h2>
        <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
          <a href="input_progress_jalan.php" class="btn btn-outline-light ms-auto">+ Tambah</a>
        <?php endif; ?>
      </div>

      <?php if ($progress && $progress->num_rows > 0): ?>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($row = $progress->fetch_assoc()): ?>
            <div class="col">
              <div class="card h-100 shadow-sm">
                <img src="<?= htmlspecialchars($row['foto']) ?>"
                     alt="<?= htmlspecialchars($row['judul']) ?>"
                     class="card-img-top">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title"><?= htmlspecialchars($row['judul']) ?></h5>
                  <p class="card-text mb-4"><?= htmlspecialchars($row['jalan']) ?></p>
                  <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                    <a href="?hapus=<?= $row['id'] ?>" class="btn btn-sm btn-danger mt-auto">
                      <i class="fas fa-trash-alt"></i> Hapus
                    </a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <p class="text-center text-muted">Belum ada dokumentasi progress jalan.</p>
      <?php endif; ?>
    </div>
  </section>

 <?php include 'footer.php'; ?>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
